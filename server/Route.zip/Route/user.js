import express from "express";
import Userdetails from "../model/userLogin";
var MongoClient = require('mongodb').MongoClient


let Router = express.Router();
Router.post('/login', (req, res) => {
    console.log(req.body.username)
    Userdetails.find({username:req.body.username}).then((result)=>{
        
            if(result.length===1&&result[0].password===req.body.password){
                console.log("ojk")
                res.json({Userexist:true});

            }else{
                res.json({Userexist:false})
            }
    }).catch((err)=>{
        console.log(err)
    })
 


});
Router.post('/signup', (req, res) => {
    var { email, password,username, matchpassword,mobile,location} = req.body;
    var userdetails={
        email:email,
        password:password,
        username:username,
        matchpassword:matchpassword,
        mobile:mobile,
        location:location
    }
    new Userdetails(userdetails).save().then((res ,err)=>{
      console.log(err,"viswa")
    }).catch((err)=>{
        console.log(err)
    })
    
 


});
export default Router;